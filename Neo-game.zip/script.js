const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// 设置画布大小并保持16:9比例适配窗口
function resizeCanvas() {
  const aspectRatio = 16 / 9;
  canvas.width = window.innerWidth;
  canvas.height = window.innerWidth / aspectRatio;

  // 如果画布高度超出窗口，则按高度适配
  if (canvas.height > window.innerHeight) {
    canvas.height = window.innerHeight;
    canvas.width = canvas.height * aspectRatio;
  }
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas); // 监听窗口大小变化

// 加载背景和人物图片
const background = new Image();
background.src = './assets/background.png';

const player = new Image();
player.src = './assets/player.png';

// 调试：检查图片加载
background.onload = () => console.log('背景图片加载成功');
background.onerror = () => console.error('背景图片加载失败');

player.onload = () => console.log('人物图片加载成功');
player.onerror = () => console.error('人物图片加载失败');

// 初始化人物和背景位置
let playerX = 100;
let playerY = canvas.height - 132;
let backgroundX = 0;
const playerSpeed = 5;

// 监听键盘事件
let keys = {};
window.addEventListener('keydown', (e) => (keys[e.key] = true));
window.addEventListener('keyup', (e) => (keys[e.key] = false));

// 更新人物位置和背景滚动
function update() {
  if (keys['ArrowRight']) {
    playerX += playerSpeed;
    backgroundX -= playerSpeed / 2;

    if (playerX > canvas.width / 2) {
      playerX = canvas.width / 2;
    }
  }

  if (keys['ArrowLeft'] && backgroundX < 0) {
    playerX -= playerSpeed;
    backgroundX += playerSpeed / 2;
  }

  playerX = Math.max(0, playerX); // 限制人物不超出左侧边界
}

// 绘制场景和人物
function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // 计算背景图片缩放比例
  const bgWidth = background.width;
  const bgHeight = background.height;
  const scale = Math.max(canvas.width / bgWidth, canvas.height / bgHeight);

  const scaledWidth = bgWidth * scale;
  const scaledHeight = bgHeight * scale;

  const xOffset = (canvas.width - scaledWidth) / 2;
  const yOffset = (canvas.height - scaledHeight) / 2;

  // 绘制背景图片，并确保按比例居中
  ctx.drawImage(background, 0, 0, bgWidth, bgHeight, xOffset, yOffset, scaledWidth, scaledHeight);

  // 绘制人物
  ctx.drawImage(player, playerX, playerY, 64, 64);
}

// 游戏循环
function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}

// 启动游戏
window.onload = () => {
  background.onload = () => {
    player.onload = () => {
      gameLoop();
    };
  };
};
